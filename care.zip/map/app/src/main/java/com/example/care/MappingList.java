package com.example.care;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class MappingList extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mapping_list);
    }
}
